
public class Voters {
	String name;
	String adress;
	int age;
	
	
	Voters(String name, String adress, int age) {
		this.name = name;
		this.adress = adress;
		this.age = age;
	}

}
