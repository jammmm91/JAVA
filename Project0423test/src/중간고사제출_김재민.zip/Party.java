
public class Party {
	String name;
	int age;
	String party;
	
	Party (String name, int age, String party) {
		this.name = name;
		this.age = age;
		this.party = party;
	}
}
