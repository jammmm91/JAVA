package com.kopo.main;

public class Apartment {

	int idx;
	String name;
	
	public Apartment() {

	}

	public Apartment(String name) {

		this.name = name;
	}
}
