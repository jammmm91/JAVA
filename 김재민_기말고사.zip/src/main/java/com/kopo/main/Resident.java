package com.kopo.main;

public class Resident {

	int idx;
	String name;
	String age;
	String sex;
	
	public Resident() {

	}

	public Resident(String name, String age, String sex) {

		this.name = name;
		this.age = age;
		this.sex = sex;
	}
}
